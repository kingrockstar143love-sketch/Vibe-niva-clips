# VIBE NOVA CLIPS

A starter Flutter app for the VIBE NOVA CLIPS Android project.

This is an initial UI prototype. Video importing, AI highlight detection, captions,
AI voice generation, and video exporting are not implemented yet.

## Build
The GitHub Actions workflow can generate the Android platform files and build
a release APK.
