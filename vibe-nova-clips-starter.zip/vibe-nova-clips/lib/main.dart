import 'package:flutter/material.dart';

void main() {
  runApp(const VibeNovaApp());
}

class VibeNovaApp extends StatelessWidget {
  const VibeNovaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VIBE NOVA CLIPS',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF101018),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF9B5CFF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'VIBE NOVA CLIPS',
          style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2),
        ),
        centerTitle: false,
        backgroundColor: const Color(0xFF171722),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: const LinearGradient(
                colors: [Color(0xFF44206E), Color(0xFF19192B)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('CREATE • EDIT • SHARE',
                    style: TextStyle(color: Color(0xFFD9BFFF), letterSpacing: 1.5)),
                SizedBox(height: 12),
                Text(
                  'Your next viral clip starts here.',
                  style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(
                  'Turn long videos into exciting short-form content.',
                  style: TextStyle(color: Colors.white70, height: 1.4),
                ),
              ],
            ),
          ),
          const SizedBox(height: 26),
          const Text('GET STARTED',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold,
                  color: Color(0xFFBFA2FF), letterSpacing: 1.5)),
          const SizedBox(height: 12),
          _ActionTile(
            icon: Icons.video_library_outlined,
            title: 'Import a video',
            subtitle: 'Choose a video from your phone',
            onTap: () => _showInfo(context, 'Video importing will be added next.'),
          ),
          _ActionTile(
            icon: Icons.auto_awesome,
            title: 'AI Clips',
            subtitle: 'Find interesting moments automatically',
            onTap: () => _showInfo(context, 'AI clip generation will be added next.'),
          ),
          _ActionTile(
            icon: Icons.subtitles_outlined,
            title: 'Captions & Voice',
            subtitle: 'Add English captions and AI voice',
            onTap: () => _showInfo(context, 'Captions and voice tools will be added next.'),
          ),
          _ActionTile(
            icon: Icons.content_cut,
            title: 'My Projects',
            subtitle: 'Your saved video projects',
            onTap: () => _showInfo(context, 'Your projects will appear here.'),
          ),
          const SizedBox(height: 20),
          const Center(
            child: Text('Made for creators • VIBE NOVA CLIPS',
                style: TextStyle(color: Colors.white38, fontSize: 12)),
          ),
        ],
      ),
    );
  }

  static void _showInfo(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFF1B1B28),
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: const Color(0xFF392653),
          child: Icon(icon, color: const Color(0xFFD7B8FF)),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.white60)),
        trailing: const Icon(Icons.chevron_right, color: Colors.white54),
        onTap: onTap,
      ),
    );
  }
}
